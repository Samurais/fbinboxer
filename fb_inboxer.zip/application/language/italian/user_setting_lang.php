<?php 
$lang["proxy"] = "delega";
$lang["proxy port"] = "porta proxy";
$lang["proxy username"] = "il nome utente del proxy";
$lang["proxy password"] = "la password del proxy";
$lang["admin permission"] = "il permesso di amministrazione";