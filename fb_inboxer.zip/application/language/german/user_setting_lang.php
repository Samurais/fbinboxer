<?php 
$lang["proxy"] = "Stellvertreter";
$lang["proxy port"] = "Proxy-Port";
$lang["proxy username"] = "Proxy-Benutzername";
$lang["proxy password"] = "Proxy-Passwort";
$lang["admin permission"] = "Admin-Berechtigung";