<?php 
$lang["proxy"] = "প্রক্সি";
$lang["proxy port"] = "প্রক্সি পোর্ট";
$lang["proxy username"] = "প্রক্সি ইউজারনেম";
$lang["proxy password"] = "প্রক্সি পাসওয়ার্ড";
$lang["admin permission"] = "অনুমতি";