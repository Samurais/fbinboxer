<?php

$lang['terabyte_abbr'] = "টিবি";
$lang['gigabyte_abbr'] = "জিবি";
$lang['megabyte_abbr'] = "এম্বি";
$lang['kilobyte_abbr'] = "কেবি";
$lang['bytes'] = "বাইট";

/* End of file number_lang.php */
/* Location: ./system/language/english/number_lang.php */