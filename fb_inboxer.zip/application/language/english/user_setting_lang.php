<?php 
$lang["proxy"] = "Proxy";
$lang["proxy port"] = "Proxy Port";
$lang["proxy username"] = "Proxy Username";
$lang["proxy password"] = "Proxy Password";
$lang["admin permission"] = "Admin Permission";