<?php 

$lang["proxy"] = "Proxy";
$lang["proxy port"] = "Cổng giao thức";
$lang["proxy username"] = "Proxy Tên đăng nhập";
$lang["proxy password"] = "Proxy Mật khẩu";
$lang["admin permission"] = "quản trị Permission";