<?php 
$config["backup_mode"] = 0; // if backup mode set to 1 then in socimarketer users will use their own apps otherwise admin's