<?php 
$config['default_page_url'] = 'page/blank';
$config['product_version'] = 'v1.1';

$config['institute_address1'] = 'XerOne IT';
$config['institute_address2'] = 'Rajshahi,Bangladesh';
$config['institute_email'] = 'jwel.cse@gmail.com';
$config['institute_mobile'] = '01723309003';

$config['slogan'] = '';
$config['product_name'] = 'FB Inboxer';
$config['product_short_name'] = 'FB Inboxer';

$config['developed_by'] = ' XerOne IT ';
$config['developed_by_href'] = 'http://xeroneit.net';
$config['developed_by_title'] = 'we think of your needs';
$config['developed_by_prefix'] = 'Developed by' ;
$config['support_email'] = 'support@xeroneit.net' ;
$config['support_mobile'] = '+88 01729 853 645' ;
$config['time_zone'] = 'Asia/Dhaka';
$config['language'] = 'english';
$config['sess_use_database'] = false;
$config['sess_table_name'] = 'ci_sessions';
$config['front_end_search_display'] = 'no';
